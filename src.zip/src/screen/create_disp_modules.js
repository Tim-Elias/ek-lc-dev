// import React, { Component } from 'react';
// import { connect } from 'react-redux';

// class Screen extends Component {

//     constructor(props) {
//         super(props);
//         this.test = this.test.bind(this);
//      }
//      componentDidMount() {
//         this.props.set_(this.test);
//      }

//     test = (val) => {
//         console.log(val)
//     }

    






    
//     render() {
        
//         return null
//     }

    
// }
// export default (connect(
//     (state) => ({ store: state }),
    
//     dispatch => ({
//         set_active_window: (param) => { dispatch({ type: 'home', payload: param }); },

//     })

// )(Screen));
